(() => {
  const background = document.createElement('div');
  background.id = 'wings-of-fire-youtube-background';
  background.style.cssText = 'position:fixed;inset:0;z-index:-1;background:center/cover fixed no-repeat;pointer-events:none';

  const style = document.createElement('style');
  style.id = 'wings-of-fire-youtube-style';
  style.textContent = `
    html, body, ytd-app, ytd-page-manager, ytd-browse, ytd-watch-flexy,
    #page-manager, #content, #primary, #secondary, #columns, #masthead-container,
    ytd-masthead, ytd-rich-grid-renderer, ytd-two-column-browse-results-renderer,
    ytd-rich-item-renderer, ytd-video-renderer { background: transparent !important; }
    ytd-masthead#masthead, #masthead-container, ytd-masthead #container,
    ytd-masthead #background, ytd-masthead #frosted-glass, ytd-masthead #scrim {
      background: transparent !important;
      background-image: none !important;
      box-shadow: none !important;
      backdrop-filter: none !important;
    }
    button, tp-yt-paper-button, yt-button-shape, yt-button-shape button,
    ytd-button-renderer, ytd-chip-cloud-chip-renderer, ytd-comments,
    ytd-comment-thread-renderer, ytd-item-section-renderer, ytd-rich-item-renderer,
    ytd-video-renderer, ytd-engagement-panel-section-list-renderer,
    ytd-watch-metadata, ytd-video-primary-info-renderer, #panels, #related {
      background-color: #160d13 !important;
      border-color: #8d6716 !important;
    }
    body > *:not(#wings-of-fire-youtube-background) { position: relative; z-index: 1; }
    body, body *, body *::before, body *::after { color: #f9c64a !important; text-shadow: 0 1px 3px #000 !important; }
    :root { --yt-spec-text-primary: #f9c64a !important; --yt-spec-text-secondary: #f9c64a !important; --yt-spec-call-to-action: #f9c64a !important; --yt-spec-base-background: transparent !important; --yt-spec-raised-background: transparent !important; }
  `;

  const applyTheme = () => {
    [
      '--yt-spec-base-background',
      '--yt-spec-raised-background',
      '--yt-spec-menu-background',
      '--yt-spec-general-background-a',
      '--yt-spec-general-background-b',
      '--yt-spec-general-background-c',
      '--yt-spec-brand-background-solid',
      '--yt-spec-additive-background',
      '--ytd-masthead-background'
    ].forEach(variable => document.documentElement.style.setProperty(variable, 'transparent', 'important'));
    ['--yt-spec-raised-background', '--yt-spec-menu-background', '--yt-spec-additive-background'].forEach(variable => document.documentElement.style.setProperty(variable, '#160d13', 'important'));
    if (!document.getElementById(background.id)) document.body.prepend(background);
    if (!document.getElementById(style.id)) document.head.append(style);
    chrome.storage.local.get({ fanwingBackground: 'assets/backgrounds/darkstalker.png' }, ({ fanwingBackground }) => {
      background.style.backgroundImage = `url("${chrome.runtime.getURL(fanwingBackground)}")`;
    });
  };

  if (document.body) applyTheme();
  else document.addEventListener('DOMContentLoaded', applyTheme, { once: true });
})();
